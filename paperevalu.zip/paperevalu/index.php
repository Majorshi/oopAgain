<?php
	if ($_SESSION['wt_id'] != null) {
		
	} else {
		header("./view/login.php");
	}
?>